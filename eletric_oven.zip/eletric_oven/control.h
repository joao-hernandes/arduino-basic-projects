#ifndef CONTROL_H
#define CONTROL_H

#include <Arduino.h>

extern const byte relayPin;                         //Pino do relay
extern const byte ledPin;

extern bool firstStopRun;
extern bool firstRun;

volatile extern bool flagControl;

extern byte controlCounter;
extern byte controlRelayTime;

void setupControl();
void controlRelay();
void controlHandle();
void peripheralsStop();
void controlStop();

#endif